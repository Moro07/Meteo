import './style.css';

import PocketBase from 'pocketbase';

const mappa = L.map("map").setView([45.25, 10.04], 3);
const datiCache = {};

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap'
}).addTo(mappa);

const db = new PocketBase('http://127.0.0.1:8090');


const aggiornaStats = (listaTemp) => {
    const valide = listaTemp.filter(v => !isNaN(v));
    
    const totale = valide.length;
    let media = "N/D", massima = "N/D", minima = "N/D";

    if (totale > 0) {
        const somma = valide.reduce((a, b) => a + b, 0);
        media = (somma / totale).toFixed(2);
        massima = Math.max(...valide).toFixed(2);
        minima = Math.min(...valide).toFixed(2);
    }

    document.getElementById("count").textContent = totale;
    document.getElementById("avg-temp").textContent = media;
    document.getElementById("max-temp").textContent = massima;
    document.getElementById("min-temp").textContent = minima;
};


const getTemperatura = async (lat, lon) => {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m`;
    const risposta = await fetch(url);

    if (!risposta.ok) 
        throw new Error(`Errore Open-Meteo: ${risposta.status}`);

    const meteo = await risposta.json();
    return meteo.current.temperature_2m;
};


const caricaTutto = async () => {
    const tempCorrenti = [];

    mappa.eachLayer(layer => {
        if (layer instanceof L.Marker)
            mappa.removeLayer(layer);
    });

    const res = await db.collection("prova").getList();
    const punti = res.items;

    await Promise.all(
        punti.map(async (p) => {
            const lat = p.geopoint.lat;
            const lon = p.geopoint.lon;
            const chiave = `${lat},${lon}`;

            let nomeArea, temperatura;

            if (datiCache[chiave]) {
                ({ nomeArea, temperatura } = datiCache[chiave]);
            } else {
                try {
                    const nomiRes = await fetch(
                        `https://nominatim.openstreetmap.org/reverse?format=geojson&lat=${lat}&lon=${lon}`
                    );
                    const geo = await nomiRes.json();
                    nomeArea = geo.features[0].properties.address.city ||
                               geo.features[0].properties.address.county ||
                               "N/D";
                } catch {
                    nomeArea = "Errore città";
                }

                try {
                    temperatura = await getTemperatura(lat, lon);
                } catch {
                    temperatura = NaN;
                }

                datiCache[chiave] = { nomeArea, temperatura };
            }

            tempCorrenti.push(parseFloat(temperatura));

            L.marker([lat, lon]).addTo(mappa)
                .bindPopup(`
                    Località: ${nomeArea} <br>
                    Lat: ${lat} <br>
                    Lon: ${lon} <br>
                    Temperatura: ${isNaN(temperatura) ? "N/D" : temperatura + " °C"}
                `);
        })
    );

    aggiornaStats(tempCorrenti);
};

caricaTutto();

mappa.on("click", async (evento) => {
    const nuovo = {
        geopoint: {
            lat: evento.latlng.lat,
            lon: evento.latlng.lng
        }
    };

    await db.collection("prova").create(nuovo);
    caricaTutto();
});